from .main import process_form_fields_with_hotkeys, FieldConfig, FieldType
